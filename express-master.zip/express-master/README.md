# express

功能介绍
-------------------------------
详细介绍：[简书](http://www.jianshu.com/p/7c5031b60b09)
* 实现提供<b>快递单号</b>和<b>快递公司</b>查询快递轨迹
* 实现<b>二维码</b>和<b>条形码</b>扫描查询
* 实现对个人查询记录保存
* 实现市场常见的国内与国际快递电话的查询与拨打
* 运行截图
![运行截图]
(http://upload-images.jianshu.io/upload_images/1156494-8769003c91cb54cd.gif?imageMogr2/auto-orient/strip)
