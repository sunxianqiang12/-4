//
//  MD5.h
//  Express
//
//  Created by LeeLom on 16/7/26.
//  Copyright © 2016年 LeeLom. All rights reserved.
//
/*
 完成MD5编码
 */

#import <Foundation/Foundation.h>

@interface MD5 : NSObject
+(NSString *)md5String:(NSString *)sourceString;

@end
