//
//  ScanQRCodeViewController.h
//  Express
//
//  Created by LeeLom on 16/8/1.
//  Copyright © 2016年 LeeLom. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ScanQRCodeViewController : UIViewController

@end
