//
//  ExpressTracesViewController.h
//  Express
//
//  Created by LeeLom on 16/7/26.
//  Copyright © 2016年 LeeLom. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ExpressInfo.h"

@interface ExpressTracesViewController : UITableViewController

@property (strong, nonatomic) ExpressInfo* express;

@end
