//
//  FirstViewController.h
//  Express
//
//  Created by LeeLom on 16/7/24.
//  Copyright © 2016年 LeeLom. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FirstViewController : UIViewController
@property (strong, nonatomic)NSString* expressComName;
@property (strong, nonatomic)NSString* expressNumQrCode;

@end

